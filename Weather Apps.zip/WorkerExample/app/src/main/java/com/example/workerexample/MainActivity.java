package com.example.workerexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private TextView jokeTv;
    WeatherRecord weatherRecords[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        jokeTv = findViewById(R.id.joke_text_view);

        // create Work request for every 15min to run the worker
        // define Constrains for the job
        Constraints constraints = new Constraints
                .Builder()
                .setRequiresCharging(false)
                .setRequiredNetworkType(NetworkType.UNMETERED)
                .build();

        // define Job Request
        PeriodicWorkRequest workRequest = new PeriodicWorkRequest
                .Builder(MyWorker.class, 1, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build();

        // execute the job
        WorkManager
                .getInstance(this)
                .enqueue(workRequest);
    }

    // subscribe to the broadcast
    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String joke = intent.getStringExtra(MyWorker.weather_KEY);
            // display the joke
            jokeTv.setText(joke);

            JSONObject jsonObject = null;
            try {
                jsonObject = new JSONObject(joke);
                int latitude = jsonObject.getInt("latitude");
                int longitude = jsonObject.getInt("longitude");
                String timezone = jsonObject.getString("timezone");
                int utc_offset_seconds = jsonObject.getInt("utc_offset_seconds");
                double generationtime_ms = jsonObject.getDouble("generationtime_ms");


            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(MyWorker.WEATHER_BROADCAST);
        registerReceiver(broadcastReceiver,filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(broadcastReceiver);
    }
}


